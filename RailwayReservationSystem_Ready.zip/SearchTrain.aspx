<%@ Page Title="Search Trains" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="SearchTrain.aspx.cs" Inherits="RailwayReservationSystem.SearchTrain" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="card"><h2 class="title">Search Trains</h2>
<div class="grid"><div><label class="label">From</label><asp:TextBox ID="txtFrom" runat="server" CssClass="input"/></div><div><label class="label">To</label><asp:TextBox ID="txtTo" runat="server" CssClass="input"/></div></div>
<asp:Button ID="btnSearch" runat="server" Text="Search Trains" CssClass="button blue" OnClick="btnSearch_Click"/>
<asp:Label ID="msg" runat="server" CssClass="msg"/>
</div>
<asp:GridView ID="gv" runat="server" AutoGenerateColumns="false" CssClass="table" GridLines="None">
<Columns>
<asp:BoundField DataField="TrainNo" HeaderText="Train No"/>
<asp:BoundField DataField="TrainName" HeaderText="Train Name"/>
<asp:BoundField DataField="Source" HeaderText="From"/>
<asp:BoundField DataField="Destination" HeaderText="To"/>
<asp:BoundField DataField="Departure" HeaderText="Departure"/>
<asp:BoundField DataField="Arrival" HeaderText="Arrival"/>
<asp:BoundField DataField="AvailableSeats" HeaderText="Seats"/>
<asp:TemplateField HeaderText="Action"><ItemTemplate><a class="button" href='BookTicket.aspx?train=<%# Eval("TrainId") %>'>Book</a></ItemTemplate></asp:TemplateField>
</Columns></asp:GridView>
</asp:Content>