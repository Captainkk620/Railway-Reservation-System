<%@ Page Title="Register" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="Register.aspx.cs" Inherits="RailwayReservationSystem.Register" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="card" style="max-width:520px;margin:auto"><h2 class="title">Create Account</h2>
<asp:Label ID="msg" runat="server" CssClass="msg"/>
<label class="label">Full Name</label><asp:TextBox ID="txtName" runat="server" CssClass="input"/>
<label class="label">Username</label><asp:TextBox ID="txtUser" runat="server" CssClass="input"/>
<label class="label">Password</label><asp:TextBox ID="txtPass" runat="server" TextMode="Password" CssClass="input"/>
<label class="label">Email</label><asp:TextBox ID="txtEmail" runat="server" CssClass="input"/>
<asp:Button ID="btnRegister" runat="server" Text="Register" CssClass="button blue" OnClick="btnRegister_Click"/>
</div></asp:Content>