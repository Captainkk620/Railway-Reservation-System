using System;using System.Configuration;using System.Data.SqlClient;
namespace RailwayReservationSystem
{
 public partial class BookTicket:System.Web.UI.Page
 {
  int TrainId=>int.TryParse(Request.QueryString["train"],out var x)?x:0;
  protected void Page_Load(object s,EventArgs e){if(Session["UserId"]==null){Response.Redirect("Login.aspx");return;}if(!IsPostBack)LoadTrain();}
  void LoadTrain(){using(var c=new SqlConnection(ConfigurationManager.ConnectionStrings["RailwayDB"].ConnectionString))using(var q=new SqlCommand("SELECT TrainNo,TrainName,Source,Destination,Departure,Arrival,AvailableSeats,Fare FROM Trains WHERE TrainId=@id",c)){q.Parameters.AddWithValue("@id",TrainId);c.Open();using(var r=q.ExecuteReader()){if(r.Read())trainInfo.Text=$"Train {r["TrainNo"]} - {r["TrainName"]} | {r["Source"]} → {r["Destination"]} | Fare ₹{r["Fare"]} | Available: {r["AvailableSeats"]}";}}}
  protected void btnBook_Click(object s,EventArgs e){
   if(!int.TryParse(txtAge.Text,out var age)||!int.TryParse(txtSeats.Text,out var seats)||age<1||seats<1){msg.Text="Enter valid age and seat count.";msg.CssClass="msg error";return;}
   using(var c=new SqlConnection(ConfigurationManager.ConnectionStrings["RailwayDB"].ConnectionString)){c.Open();var tx=c.BeginTransaction();
    try{
     int avail;decimal fare;using(var q=new SqlCommand("SELECT AvailableSeats,Fare FROM Trains WITH (UPDLOCK) WHERE TrainId=@id",c,tx)){q.Parameters.AddWithValue("@id",TrainId);using(var r=q.ExecuteReader()){if(!r.Read())throw new Exception("Train not found.");avail=(int)r["AvailableSeats"];fare=(decimal)r["Fare"];}}
     if(seats>avail)throw new Exception("Not enough seats available.");
     string pnr="PNR"+DateTime.Now.ToString("yyyyMMddHHmmssfff").Substring(4);
     using(var q=new SqlCommand("INSERT INTO Bookings(PNR,UserId,TrainId,PassengerName,Age,Gender,Seats,TotalFare,BookingDate,Status) VALUES(@pnr,@u,@t,@n,@a,@g,@s,@f,GETDATE(),'Booked')",c,tx)){
      q.Parameters.AddWithValue("@pnr",pnr);q.Parameters.AddWithValue("@u",(int)Session["UserId"]);q.Parameters.AddWithValue("@t",TrainId);q.Parameters.AddWithValue("@n",txtName.Text.Trim());q.Parameters.AddWithValue("@a",age);q.Parameters.AddWithValue("@g",ddlGender.SelectedValue);q.Parameters.AddWithValue("@s",seats);q.Parameters.AddWithValue("@f",fare*seats);q.ExecuteNonQuery();}
     using(var q=new SqlCommand("UPDATE Trains SET AvailableSeats=AvailableSeats-@s WHERE TrainId=@id",c,tx)){q.Parameters.AddWithValue("@s",seats);q.Parameters.AddWithValue("@id",TrainId);q.ExecuteNonQuery();}
     tx.Commit();Response.Redirect("MyBookings.aspx");
    }catch(Exception ex){tx.Rollback();msg.Text=ex.Message;msg.CssClass="msg error";}
   }
  }
 }
}