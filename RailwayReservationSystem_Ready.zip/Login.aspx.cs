using System;
using System.Configuration;
using System.Data.SqlClient;
namespace RailwayReservationSystem
{
 public partial class Login:System.Web.UI.Page
 {
  protected void btnLogin_Click(object s,EventArgs e){
   using(var c=new SqlConnection(ConfigurationManager.ConnectionStrings["RailwayDB"].ConnectionString))
   using(var q=new SqlCommand("SELECT UserId,FullName,IsAdmin FROM Users WHERE Username=@u AND PasswordHash=@p",c)){
    q.Parameters.AddWithValue("@u",txtUser.Text.Trim()); q.Parameters.AddWithValue("@p",txtPass.Text);
    c.Open(); using(var r=q.ExecuteReader()){
     if(r.Read()){Session["UserId"]=r["UserId"];Session["FullName"]=r["FullName"];Session["IsAdmin"]=r["IsAdmin"];Response.Redirect("Default.aspx");}
     else {msg.Text="Invalid username or password.";msg.CssClass="msg error";}
    }
   }
  }
 }
}