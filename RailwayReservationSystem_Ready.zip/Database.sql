CREATE DATABASE RailwayReservationDB;
GO
USE RailwayReservationDB;
GO

CREATE TABLE Users(
 UserId INT IDENTITY(1,1) PRIMARY KEY,
 FullName NVARCHAR(100) NOT NULL,
 Username NVARCHAR(50) NOT NULL UNIQUE,
 PasswordHash NVARCHAR(100) NOT NULL,
 Email NVARCHAR(100),
 IsAdmin BIT NOT NULL DEFAULT 0
);

CREATE TABLE Trains(
 TrainId INT IDENTITY(1,1) PRIMARY KEY,
 TrainNo NVARCHAR(20) NOT NULL,
 TrainName NVARCHAR(100) NOT NULL,
 Source NVARCHAR(100) NOT NULL,
 Destination NVARCHAR(100) NOT NULL,
 Departure NVARCHAR(20) NOT NULL,
 Arrival NVARCHAR(20) NOT NULL,
 AvailableSeats INT NOT NULL,
 Fare DECIMAL(10,2) NOT NULL
);

CREATE TABLE Bookings(
 BookingId INT IDENTITY(1,1) PRIMARY KEY,
 PNR NVARCHAR(30) NOT NULL UNIQUE,
 UserId INT NOT NULL,
 TrainId INT NOT NULL,
 PassengerName NVARCHAR(100) NOT NULL,
 Age INT NOT NULL,
 Gender NVARCHAR(20),
 Seats INT NOT NULL,
 TotalFare DECIMAL(10,2) NOT NULL,
 BookingDate DATETIME NOT NULL,
 Status NVARCHAR(20) NOT NULL,
 FOREIGN KEY(UserId) REFERENCES Users(UserId),
 FOREIGN KEY(TrainId) REFERENCES Trains(TrainId)
);

INSERT INTO Users(FullName,Username,PasswordHash,Email,IsAdmin)
VALUES('Administrator','admin','admin123','admin@railway.local',1);

INSERT INTO Trains(TrainNo,TrainName,Source,Destination,Departure,Arrival,AvailableSeats,Fare)
VALUES
('12601','Chennai Express','Chennai','Bengaluru','06:00','11:00',120,450),
('12603','Chennai Superfast','Chennai','Coimbatore','07:30','14:00',150,520),
('12605','Rockfort Express','Chennai','Tiruchirappalli','20:30','05:30',100,600),
('12606','Pallavan Express','Chennai','Madurai','08:00','15:00',90,550),
('12607','Kaveri Express','Bengaluru','Chennai','21:00','05:00',130,480);
GO
