using System;using System.Configuration;using System.Data;using System.Data.SqlClient;
namespace RailwayReservationSystem
{
 public partial class SearchTrain:System.Web.UI.Page
 {
  protected void btnSearch_Click(object s,EventArgs e){
   using(var c=new SqlConnection(ConfigurationManager.ConnectionStrings["RailwayDB"].ConnectionString))
   using(var q=new SqlCommand("SELECT TrainId,TrainNo,TrainName,Source,Destination,Departure,Arrival,AvailableSeats FROM Trains WHERE (@f='' OR Source LIKE '%'+@f+'%') AND (@t='' OR Destination LIKE '%'+@t+'%')",c)){
    q.Parameters.AddWithValue("@f",txtFrom.Text.Trim());q.Parameters.AddWithValue("@t",txtTo.Text.Trim());var d=new SqlDataAdapter(q);var dt=new DataTable();d.Fill(dt);gv.DataSource=dt;gv.DataBind();msg.Text=dt.Rows.Count+" train(s) found.";msg.CssClass="msg success";
   }
  }
 }
}