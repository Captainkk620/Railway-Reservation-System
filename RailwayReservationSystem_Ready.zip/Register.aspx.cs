using System;
using System.Configuration;
using System.Data.SqlClient;
namespace RailwayReservationSystem
{
 public partial class Register:System.Web.UI.Page
 {
  protected void btnRegister_Click(object s,EventArgs e){
   if(txtName.Text.Trim()==""||txtUser.Text.Trim()==""||txtPass.Text==""){msg.Text="Please fill required fields.";msg.CssClass="msg error";return;}
   using(var c=new SqlConnection(ConfigurationManager.ConnectionStrings["RailwayDB"].ConnectionString))
   {c.Open();using(var q=new SqlCommand("INSERT INTO Users(FullName,Username,PasswordHash,Email,IsAdmin) VALUES(@n,@u,@p,@e,0)",c)){
    q.Parameters.AddWithValue("@n",txtName.Text.Trim());q.Parameters.AddWithValue("@u",txtUser.Text.Trim());q.Parameters.AddWithValue("@p",txtPass.Text);q.Parameters.AddWithValue("@e",txtEmail.Text.Trim());
    try{q.ExecuteNonQuery();msg.Text="Registration successful. You can now login.";msg.CssClass="msg success";}catch{msg.Text="Username already exists.";msg.CssClass="msg error";}
   }}
  }
 }
}