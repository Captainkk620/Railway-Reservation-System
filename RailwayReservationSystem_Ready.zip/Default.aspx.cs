using System;
namespace RailwayReservationSystem { public partial class _Default : System.Web.UI.Page { } }