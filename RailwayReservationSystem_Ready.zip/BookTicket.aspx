<%@ Page Title="Book Ticket" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="BookTicket.aspx.cs" Inherits="RailwayReservationSystem.BookTicket" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="card"><h2 class="title">Passenger Details</h2><asp:Label ID="trainInfo" runat="server" CssClass="msg"/>
<asp:Label ID="msg" runat="server" CssClass="msg"/>
<label class="label">Passenger Name</label><asp:TextBox ID="txtName" runat="server" CssClass="input"/>
<label class="label">Age</label><asp:TextBox ID="txtAge" runat="server" CssClass="input"/>
<label class="label">Gender</label><asp:DropDownList ID="ddlGender" runat="server" CssClass="input"><asp:ListItem>Male</asp:ListItem><asp:ListItem>Female</asp:ListItem><asp:ListItem>Other</asp:ListItem></asp:DropDownList>
<label class="label">Number of Seats</label><asp:TextBox ID="txtSeats" runat="server" Text="1" CssClass="input"/>
<asp:Button ID="btnBook" runat="server" Text="Confirm Booking" CssClass="button blue" OnClick="btnBook_Click"/>
</div></asp:Content>