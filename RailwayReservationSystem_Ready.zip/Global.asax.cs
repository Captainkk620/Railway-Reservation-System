using System;
using System.Web;

namespace RailwayReservationSystem
{
    public class Global : HttpApplication
    {
        protected void Application_Start(object sender, EventArgs e) { }
    }
}
