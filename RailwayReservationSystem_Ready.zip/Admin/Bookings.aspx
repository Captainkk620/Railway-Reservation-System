<%@ Page Title="Admin - Bookings" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="Bookings.aspx.cs" Inherits="RailwayReservationSystem.Admin.Bookings" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="card"><h2 class="title">All Bookings</h2><asp:GridView ID="gv" runat="server" AutoGenerateColumns="true" CssClass="table" GridLines="None"/></div>
</asp:Content>