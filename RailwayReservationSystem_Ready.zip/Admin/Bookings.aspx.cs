using System;using System.Configuration;using System.Data;using System.Data.SqlClient;
namespace RailwayReservationSystem.Admin
{
 public partial class Bookings:System.Web.UI.Page
 {
  protected void Page_Load(object s,EventArgs e){if(Session["IsAdmin"]==null||!(bool)Session["IsAdmin"]){Response.Redirect("../Login.aspx");return;}if(!IsPostBack)Load();}
  void Load(){using(var c=new SqlConnection(ConfigurationManager.ConnectionStrings["RailwayDB"].ConnectionString))using(var q=new SqlCommand("SELECT b.PNR,u.FullName,t.TrainName,b.PassengerName,b.Seats,b.TotalFare,b.Status,b.BookingDate FROM Bookings b JOIN Users u ON b.UserId=u.UserId JOIN Trains t ON b.TrainId=t.TrainId ORDER BY b.BookingId DESC",c)){var d=new SqlDataAdapter(q);var dt=new DataTable();d.Fill(dt);gv.DataSource=dt;gv.DataBind();}}
 }
}