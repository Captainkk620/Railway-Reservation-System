<%@ Page Title="Admin - Trains" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="Trains.aspx.cs" Inherits="RailwayReservationSystem.Admin.Trains" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="card"><h2 class="title">Admin - Manage Trains</h2><asp:Label ID="msg" runat="server" CssClass="msg"/>
<div class="grid"><asp:TextBox ID="no" runat="server" CssClass="input" placeholder="Train No"/><asp:TextBox ID="name" runat="server" CssClass="input" placeholder="Train Name"/><asp:TextBox ID="src" runat="server" CssClass="input" placeholder="Source"/><asp:TextBox ID="dest" runat="server" CssClass="input" placeholder="Destination"/><asp:TextBox ID="dep" runat="server" CssClass="input" placeholder="Departure (09:00)"/><asp:TextBox ID="arr" runat="server" CssClass="input" placeholder="Arrival (15:00)"/><asp:TextBox ID="seats" runat="server" CssClass="input" placeholder="Seats"/><asp:TextBox ID="fare" runat="server" CssClass="input" placeholder="Fare"/></div>
<asp:Button ID="add" runat="server" Text="Add Train" CssClass="button blue" OnClick="add_Click"/>
</div>
<asp:GridView ID="gv" runat="server" AutoGenerateColumns="true" CssClass="table" GridLines="None"/>
</asp:Content>