using System;using System.Configuration;using System.Data;using System.Data.SqlClient;
namespace RailwayReservationSystem.Admin
{
 public partial class Trains:System.Web.UI.Page
 {
  protected void Page_Load(object s,EventArgs e){if(Session["IsAdmin"]==null||!(bool)Session["IsAdmin"]){Response.Redirect("../Login.aspx");return;}if(!IsPostBack)Load();}
  void Load(){using(var c=new SqlConnection(ConfigurationManager.ConnectionStrings["RailwayDB"].ConnectionString))using(var q=new SqlCommand("SELECT TrainId,TrainNo,TrainName,Source,Destination,Departure,Arrival,AvailableSeats,Fare FROM Trains ORDER BY TrainNo",c)){var d=new SqlDataAdapter(q);var dt=new DataTable();d.Fill(dt);gv.DataSource=dt;gv.DataBind();}}
  protected void add_Click(object s,EventArgs e){if(no.Text==""||name.Text==""||src.Text==""||dest.Text==""){msg.Text="Fill the required fields.";msg.CssClass="msg error";return;}if(!int.TryParse(seats.Text,out var ss)||!decimal.TryParse(fare.Text,out var ff)){msg.Text="Enter valid seats and fare.";msg.CssClass="msg error";return;}using(var c=new SqlConnection(ConfigurationManager.ConnectionStrings["RailwayDB"].ConnectionString))using(var q=new SqlCommand("INSERT INTO Trains(TrainNo,TrainName,Source,Destination,Departure,Arrival,AvailableSeats,Fare) VALUES(@n,@name,@s,@d,@dep,@arr,@ss,@f)",c)){q.Parameters.AddWithValue("@n",no.Text);q.Parameters.AddWithValue("@name",name.Text);q.Parameters.AddWithValue("@s",src.Text);q.Parameters.AddWithValue("@d",dest.Text);q.Parameters.AddWithValue("@dep",dep.Text);q.Parameters.AddWithValue("@arr",arr.Text);q.Parameters.AddWithValue("@ss",ss);q.Parameters.AddWithValue("@f",ff);c.Open();q.ExecuteNonQuery();}msg.Text="Train added.";msg.CssClass="msg success";Load();}
 }
}