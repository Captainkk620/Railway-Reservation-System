<%@ Page Title="Login" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="Login.aspx.cs" Inherits="RailwayReservationSystem.Login" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="card" style="max-width:480px;margin:auto"><h2 class="title">User Login</h2>
<asp:Label ID="msg" runat="server" CssClass="msg"/>
<label class="label">Username</label><asp:TextBox ID="txtUser" runat="server" CssClass="input"/>
<label class="label">Password</label><asp:TextBox ID="txtPass" runat="server" TextMode="Password" CssClass="input"/>
<asp:Button ID="btnLogin" runat="server" Text="Login" CssClass="button blue" OnClick="btnLogin_Click"/>
<p class="small">New user? <a href="Register.aspx">Create an account</a></p></div>
</asp:Content>