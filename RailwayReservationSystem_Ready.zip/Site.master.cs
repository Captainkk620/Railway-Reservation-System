using System;
using System.Web.UI;

namespace RailwayReservationSystem
{
    public partial class SiteMaster : MasterPage { }
}
