<%@ Page Title="Home" Language="C#" MasterPageFile="~/Site.master" AutoEventWireup="true" CodeFile="Default.aspx.cs" Inherits="RailwayReservationSystem._Default" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">
<div class="hero">
<h1>Railway Reservation System</h1>
<p>Search trains, check availability and reserve your journey online.</p>
<a class="btn" href="SearchTrain.aspx">Search & Book Train</a>
</div>
<div class="grid" style="margin-top:22px">
<div class="card"><div class="stat">🚆</div><h3>Train Search</h3><p>Find trains between stations.</p></div>
<div class="card"><div class="stat">🎫</div><h3>Easy Booking</h3><p>Reserve seats and generate a PNR.</p></div>
<div class="card"><div class="stat">📋</div><h3>Manage Tickets</h3><p>View and cancel your bookings.</p></div>
</div>
</asp:Content>