# Railway Reservation System

A college-level Railway Reservation System built using ASP.NET Web Forms, C#, and SQL Server.

## Features
- User registration and login
- Search trains by source and destination
- Seat availability
- Passenger booking
- Ticket/PNR generation
- My bookings
- Ticket cancellation
- Admin train management
- Admin booking view

## Technology
- ASP.NET Web Forms
- C#
- SQL Server
- HTML/CSS
- Visual Studio 2022

## Setup
1. Open `RailwayReservationSystem.sln` in Visual Studio 2022.
2. Make sure ASP.NET Web Forms/.NET Framework 4.8 development tools are installed.
3. Open `Database.sql` in SQL Server Management Studio and execute it.
4. If your SQL Server instance is different from `(localdb)\MSSQLLocalDB`, edit the connection string in `Web.config`.
5. Run the project with IIS Express.

## Demo admin
Username: admin
Password: admin123

## Demo user
You can register a new account from the Register page.
